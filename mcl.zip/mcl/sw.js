const V='mcl-v3',F=['./','index.html','css/style.css','js/boot.js','js/config.js','js/theme.js','js/app.js','manifest.json','icons/icon.svg','icons/icon-192.png','icons/icon-512.png','js/xlsx.full.min.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(V).then(c=>Promise.all(F.map(u=>c.add(u).catch(()=>{})))).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;
e.respondWith(caches.match(e.request).then(r=>{const f=fetch(e.request).then(x=>{if(x&&(x.ok||x.type==='opaque')){const y=x.clone();caches.open(V).then(c=>c.put(e.request,y))}return x}).catch(()=>r||caches.match('index.html'));return r||f}))});
