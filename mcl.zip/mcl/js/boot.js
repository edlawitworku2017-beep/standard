/* ስህተት ቢኖር ባዶ ገጽ ፋንታ መልዕክት ያሳያል */
(function(){function show(m){var a=document.getElementById('app');if(a&&!a.querySelector('.card,header'))a.innerHTML='<div style="padding:20px;font-family:sans-serif"><h3>⚠ ሲስተሙ አልተከፈተም / App failed to start</h3><p style="word-break:break-all">'+String(m).replace(/</g,'&lt;')+'</p><p>Chrome/Safari ውስጥ የ https አድራሻውን (Netlify) ክፈት። ፋይሉን ከ Files/ዚፕ በቀጥታ አትክፈት። / Open the hosted https address, not the local file.</p></div>'}
window.addEventListener('error',function(e){show((e.message||'error')+' '+(e.filename||'')+':'+(e.lineno||''))});
window.addEventListener('unhandledrejection',function(e){show(e.reason&&e.reason.message||e.reason)});
})();
