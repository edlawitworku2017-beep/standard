/* ዋና ቅንብር — API_URL: የGoogle Apps Script Web App አድራሻ እዚህ ይለጠፋል */
window.CFG={
 APP:'መነሃሪያ ቼክ ሊስት',VER:'1.0',
 API_URL:'',
 TITLE_AM:'በወረዳ/ጠ/ሰ/ሁ/ዞን መንገድና ትራንስፖርት መምሪያ በኢንስፔክሽን ቡድን የተዘጋጀ የመነሀሪያ ስታንዳርድ መለኪያ ቼክ ሊስት',
 TITLE_EN:'Terminal standard measurement checklist prepared by the Woreda/Zone Road and Transport Department Inspection Team',
 SECS:[{id:'s1',am:'ዋና መስፈርቶች',en:'Main standards'},{id:'s2',am:'ተጨማሪ መስፈርቶች',en:'Additional standards'}],
 /* [ክፍል, ክብደት, አማርኛ, English] — ተ.ቁ.1 ክብደት በሰነዱ ባዶ ስለነበር 0 ነው (በአድሚን ይስተካከላል) */
 ITEMS:[
 ['s1',0,'የመንገደኞች እቃ አስመዝኖ በመጫን አገልግሎት መስጠት /በዞኑ መናሀሪያ ደረጀ የሚፈፀም/','Providing luggage weighing-and-loading service for passengers (implemented at zone terminal level)'],
 ['s1',7.77,'የግንዛቤ መፍጠር ሚኒ ሚዲያ ማዘጋጀት ት/ም መስጠት','Preparing awareness-creation mini-media and giving training'],
 ['s1',7.77,'ከወያላና ደላላ የፀዳ እንግልት የሌለበት መናሀሪያ መፍጠር','Creating a terminal free of touts and brokers, without harassment'],
 ['s1',7.77,'ጫኝና አውራጅ ከተጓዡ ገንዘብ አለመቀበል','Loaders and unloaders not collecting money from travelers'],
 ['s1',7.77,'መነሻና መድረሻ ታፔላ ኬ.ሜ ታሪፍ ተሽከርካሪ ላይ መለጠፍ','Posting origin/destination sign, km and tariff on vehicles'],
 ['s1',7.77,'ከተጓዡ ትኬት መቁረጥና ደረሰኝ መስጠት','Selling tickets to passengers and issuing receipts'],
 ['s1',7.77,'የተሸከርካሪ መውጫ ትኬት መቁረጥ','Issuing vehicle exit tickets'],
 ['s1',7.77,'የሹፌር ጋወንና ባጅ ለብሶ አገልግሎት መስጠት','Drivers providing service wearing gown and badge'],
 ['s1',7.77,'የረዳት ጋወንና ባጅ ለብሶ አገልግሎት መስጠት','Assistants providing service wearing gown and badge'],
 ['s1',7.77,'የተሽከርካሪዎች የበር ፍተሻ ማድረግ','Conducting gate inspection of vehicles'],
 ['s2',3,'የተሟላ ሰሌዳ ይዞ መውጣትና መግባት','Entering and leaving with complete license plates'],
 ['s2',3,'በመናሀሪያ ውስጥ መፀዳጃ ቤት መኖር','Having a toilet inside the terminal'],
 ['s2',3,'በመናሀሪያ ውስጥ ካፌና ሬስቶራንት መኖር','Having a café and restaurant inside the terminal'],
 ['s2',3,'የተኬት ኮሪደር ማዘጋጀትና ጥቅም ላይ ማዋል','Preparing and using a ticket corridor'],
 ['s2',3,'የመናሀሪያ ጽዳትን ማሰጠበቅና ለተገልጋይ ምቹ ማድረግ','Keeping the terminal clean and comfortable for customers'],
 ['s2',3,'የዘመኑን የኦፕሬተር ፍቃድ አድሶ እንዲስራ ማድረግ','Renewing the current operator license and operating with it'],
 ['s2',3,'የተሽከርካሪዎች የዘመኑ የቴክኒክ ምርመራ አድርጎ ቦሎ መለጠፍ','Vehicles having current technical inspection with the sticker posted'],
 ['s2',3,'የተሽከርካሪዎች የደረጃ እስቲከር ቀለም ማስቀባት','Painting the vehicles\' grade-sticker colors'],
 ['s2',3,'ለተደራሽ መናሀሪያዎች መርሃ-ግብ ልውውጥ ማድረግ','Exchanging schedules with connected terminals'],
 ['s2',3,'የእንግዳ ማሪፊያ አዳራሽ መኖር','Having a guest waiting hall']
 ]
};
