/** መነሃሪያ ቼክ ሊስት — Google Apps Script backend (Google Sheet ጋር የተያያዘ) */
const ADMIN_KEY='ይህንን-ቀይር-123456'; // ← የአድሚን የይለፍ ቃል (ቀይረው!)
const ss_=()=>SpreadsheetApp.getActiveSpreadsheet();
const sh_=(n,h)=>{let s=ss_().getSheetByName(n);if(!s){s=ss_().insertSheet(n);s.appendRow(h)}return s};
const out_=o=>ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
const RH=['id','office','terminal','date','total','status','updated','json'];
function cfg_(){const v=sh_('Config',['key','json']).getDataRange().getValues();for(let i=1;i<v.length;i++)if(v[i][0]==='cfg')return JSON.parse(v[i][1]);return{items:[],secs:[],offices:[]}}
function setCfg_(c){const s=sh_('Config',['key','json']),v=s.getDataRange().getValues();for(let i=1;i<v.length;i++)if(v[i][0]==='cfg'){s.getRange(i+1,2).setValue(JSON.stringify(c));return}s.appendRow(['cfg',JSON.stringify(c)])}
function total_(r){return Math.round((r.snap||[]).reduce((a,x)=>a+Math.min(Number(r.sc&&r.sc[x.id])||0,x.w),0)*100)/100}
function upsert_(r){const s=sh_('Records',RH),v=s.getDataRange().getValues(),row=[r.id,r.o||'',r.t||'',r.d||'',total_(r),r.st,r.u||Date.now(),JSON.stringify(r)];
 for(let i=1;i<v.length;i++)if(String(v[i][0])===String(r.id)){s.getRange(i+1,1,1,8).setValues([row]);return v[i][5]}s.appendRow(row);return null}
function doGet(){return out_({ok:true,msg:'checklist api'})}
function doPost(e){const L=LockService.getScriptLock();L.waitLock(20000);try{return out_(route_(JSON.parse(e.postData.contents)))}catch(x){return out_({ok:false,err:String(x)})}finally{L.releaseLock()}}
function route_(d){const cfg=cfg_(),adm=d.role==='admin'&&d.key===ADMIN_KEY,off=d.role==='office'?(cfg.offices||[]).find(o=>o.id===d.office&&String(o.code)===String(d.code)):null,no={ok:false,err:'denied'};
 switch(d.action){
 case 'auth':return{ok:!!(adm||off)};
 case 'getConfig':return{ok:true,items:cfg.items,secs:cfg.secs,offices:adm?cfg.offices:(cfg.offices||[]).map(o=>({id:o.id,name:o.name}))};
 case 'saveConfig':if(!adm)return no;setCfg_({items:d.items,secs:d.secs,offices:d.offices});return{ok:true};
 case 'list':{if(!adm&&!off)return no;const v=sh_('Records',RH).getDataRange().getValues(),recs=[];for(let i=1;i<v.length;i++)if(adm||v[i][1]===off.id)recs.push(JSON.parse(v[i][7]));return{ok:true,recs}}
 case 'submit':{if(!off)return no;const r=d.rec;r.o=off.id;r.of=off.name;r.st='pending';r.u=Date.now();const old=upsertGuard_(r);return old?{ok:false,err:'approved'}:{ok:true}}
 case 'push':if(!adm)return no;(d.recs||[]).forEach(upsert_);return{ok:true};
 case 'delete':{if(!adm)return no;const ids=(d.ids||[d.id]).map(String),s=sh_('Records',RH),v=s.getDataRange().getValues();for(let i=v.length-1;i>=1;i--)if(ids.indexOf(String(v[i][0]))>=0)s.deleteRow(i+1);return{ok:true}}
 }return{ok:false,err:'unknown'}}
function upsertGuard_(r){const v=sh_('Records',RH).getDataRange().getValues();for(let i=1;i<v.length;i++)if(String(v[i][0])===String(r.id)&&v[i][5]==='approved')return true;upsert_(r);return false}
